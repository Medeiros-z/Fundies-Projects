import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;
import tester.*;
import javalib.impworld.*;
import java.awt.Color;
import javalib.worldimages.*;

// Represents the light em all game world
class LightEmAllHex extends World {
  // a list of columns of GamePieces,
  // i.e., represents the board in column-major order
  ArrayList<ArrayList<GamePieceHex>> board;
  ArrayList<GamePieceHex> nodes; // a list of all nodes
  ArrayList<EdgeHex> mst; // a list of edges of the minimum spanning tree
  // the width and height of the board
  int width;
  int height;
  // the current location of the power station,
  // as well as its effective radius
  int powerRow;
  int powerCol;
  int radius;
  boolean won; // has the player won the game
  int time; // keep track of time to complete the current game
  Random rand;

  // Constructor for LightEmAll
  LightEmAllHex(Random r) {
    this.board = new ArrayList<ArrayList<GamePieceHex>>();
    this.nodes = new ArrayList<GamePieceHex>();
    this.mst = new ArrayList<EdgeHex>();
    this.width = IUtilsHex.GAME_WIDTH;
    this.height = IUtilsHex.GAME_HEIGHT;
    this.powerRow = 0;
    this.powerCol = 0;
    this.radius = 5;
    this.won = false;
    this.time = 0;
    this.rand = r;

    // Generate the game grid and randomize the board
    this.generateHexGrid();
    this.generateMst();
    this.randomizeBoard();

    // Set the power station at the origin
    this.board.get(powerCol).get(powerRow).updatePowerStation();
    this.bfs();
  }

  // Constructor for LightEmAll testing
  LightEmAllHex(Random r, int width, int height) {
    this.board = new ArrayList<ArrayList<GamePieceHex>>();
    this.nodes = new ArrayList<GamePieceHex>();
    this.mst = new ArrayList<EdgeHex>();
    this.width = width;
    this.height = height;
    this.powerRow = 0;
    this.powerCol = 0;
    this.radius = 10;
    this.won = false;
    this.time = 0;
    this.rand = r;
  }

  // Render the game scene
  public WorldScene makeScene() {
    WorldScene ws = new WorldScene(IUtilsHex.SCREEN_WIDTH, IUtilsHex.SCREEN_HEIGHT);

    // Render Win
    if (this.won) {
      ws.placeImageXY(new TextImage("You Won", 50, Color.GREEN), IUtilsHex.SCREEN_WIDTH / 2,
          IUtilsHex.SCREEN_HEIGHT / 2);
      ws.placeImageXY(new TextImage("Press R to restart", 50, Color.BLACK),
          IUtilsHex.SCREEN_WIDTH / 2, IUtilsHex.SCREEN_HEIGHT / 2 + 55);
      ws.placeImageXY(new TextImage("Timer: " + this.time, 50, Color.BLACK),
          IUtilsHex.SCREEN_WIDTH / 2, IUtilsHex.SCREEN_HEIGHT / 2 + 110);
      return ws;
    }

    // Render each game piece on the scene
    for (int i = 0; i < this.board.size(); i++) {
      for (int j = 0; j < this.board.get(i).size(); j++) {
        GamePieceHex gp = this.board.get(i).get(j);
        int distanceFromPS = (int) Math.sqrt(
            Math.pow(Math.abs(i - this.powerRow), 2) + Math.pow(Math.abs(j - this.powerCol), 2));
        Color wireColor = new Color(255, 255 - 25 * distanceFromPS, 0);
        ws.placeImageXY(gp.draw(IUtilsHex.TILE_SIZE, IUtilsHex.WIRE_WIDTH, wireColor),
            IUtilsHex.TILE_SIZE * i + (j % 2 == 0 ? 0 : IUtilsHex.TILE_SIZE / 2),
            IUtilsHex.TILE_SIZE * j * 3 / 4);
      }
    }

    // Place timer on screen
    ws.placeImageXY(new TextImage("Timer: " + this.time, 40, Color.BLACK),
        IUtilsHex.SCREEN_WIDTH / 2, IUtilsHex.SCREEN_HEIGHT - 45);

    return ws;

  }

  // Handle mouse clicks
  public void onMouseClicked(Posn posn, String button) {
    // Calculate the row and column of the clicked cell
    int clickedRow = posn.x / IUtilsHex.TILE_SIZE;
    int clickedCol = posn.y / (IUtilsHex.TILE_SIZE * 3 / 4);

    if (this.won) {
      return;
    }

    // Rotate the clicked cell if within game boundaries
    if (clickedRow >= 0 && clickedRow < this.height && clickedCol >= 0 && clickedCol < this.width) {
      this.board.get(clickedRow).get(clickedCol).rotate(1);
    }
    this.bfs();
  }

  // Handle key events (arrow keys to move the power station)
  public void onKeyEvent(String key) {
    if (this.won) {
      if (key.equals("r")) {
        this.board = new ArrayList<ArrayList<GamePieceHex>>();
        this.nodes = new ArrayList<GamePieceHex>();
        this.mst = new ArrayList<EdgeHex>();
        this.powerRow = 0;
        this.powerCol = 0;
        this.won = false;
        this.time = 0;
        this.generateHexGrid();
        this.generateMst();
        this.randomizeBoard();
        this.board.get(powerCol).get(powerRow).updatePowerStation();
        this.bfs();
      }
      return;
    }

    int newRow = this.powerRow;
    int newCol = this.powerCol;

    if (key.equals("up")) {
      newCol -= 1;
    }
    else if (key.equals("down")) {
      newCol += 1;
    }
    else if (key.equals("left")) {
      newRow -= 1;
    }
    else if (key.equals("right")) {
      newRow += 1;
    }

    // Move the power station if within game boundaries and connected to the new
    // position
    if (newRow >= 0 && newRow < this.height && newCol >= 0 && newCol < this.width) {
      GamePieceHex newPiece = this.board.get(newRow).get(newCol);
      if (newPiece.isConnectedTo(this.board.get(powerRow).get(powerCol))) {
        this.board.get(powerRow).get(powerCol).updatePowerStation();
        newPiece.updatePowerStation();
        this.powerRow = newRow;
        this.powerCol = newCol;
      }
    }
    this.bfs();
  }

  // On tick method, update timer every tick if game is being played
  public void onTick() {
    if (!this.won) {
      this.time += 1;
    }
  }

  // Generate a hexagonal grid
  void generateHexGrid() {
    for (int col = 0; col < this.height; col++) {
      ArrayList<GamePieceHex> row = new ArrayList<GamePieceHex>();
      int rowOffset = col % 2 == 0 ? 0 : 1; // Offset for odd columns
      for (int rowIdx = 0; rowIdx < this.width - rowOffset; rowIdx++) {
        GamePieceHex gp = new GamePieceHex(rowIdx + rowOffset, col);
        row.add(gp);
        this.nodes.add(gp);
      }
      this.board.add(row);
    }
  }

  // Randomize the board by rotating pieces randomly
  void randomizeBoard() {
    for (ArrayList<GamePieceHex> row : this.board) {
      for (GamePieceHex piece : row) {
        piece.rotate(this.rand.nextInt(6));
      }
    }
  }

  // Breath First Search to light up the game pieces
  void bfs() {
    ArrayList<GamePieceHex> worklist = new ArrayList<GamePieceHex>();
    ArrayList<GamePieceHex> alreadySeen = new ArrayList<GamePieceHex>();

    for (int col = 0; col < this.board.size(); col++) {
      for (int row = 0; row < this.board.size(); row++) {
        this.board.get(col).get(row).powered = false;
      }
    }

    this.board.get(powerRow).get(powerCol).powered = true;
    worklist.add(this.board.get(powerRow).get(powerCol));

    // As long as the work list isn't empty...
    while (!worklist.isEmpty()) {
      GamePieceHex next = worklist.remove(0);

      // If piece isn't in radius of the power station abort the bfs
      int distanceFromPS = (int) Math.sqrt(Math.pow(Math.abs(next.row - this.powerRow), 2)
          + Math.pow(Math.abs(next.col - this.powerCol), 2));
      if (distanceFromPS > this.radius) {
        break;
      }

      // Process neighbors
      for (GamePieceHex neighbor : next.getHexNeighbors(this.board)) {
        if (!alreadySeen.contains(neighbor)) {
          worklist.add(neighbor);
          alreadySeen.add(neighbor);
          neighbor.powered = true;
        }
      }
    }

    this.won = alreadySeen.size() == this.height * this.width;
  }

  // Generate minimum spanning tree and set it to this.mst
  void generateMst() {
    HashMap<GamePieceHex, GamePieceHex> representatives = new HashMap<GamePieceHex, GamePieceHex>();
    ArrayList<EdgeHex> edgesInTree = new ArrayList<EdgeHex>();
    ArrayList<EdgeHex> worklist = new ArrayList<EdgeHex>();

    // Set representatives
    for (GamePieceHex gp : this.nodes) {
      representatives.put(gp, gp);
    }

    // Generate edges and add them to the work list
    for (int col = 0; col < this.board.size(); col++) {
      for (int row = 0; row < this.board.get(col).size(); row++) {
        GamePieceHex current = this.board.get(col).get(row);
        // Check connections to the neighbors
        for (GamePieceHex neighbor : current.getHexNeighbors(this.board)) {
          worklist.add(new EdgeHex(current, neighbor, rand.nextInt(100)));
        }
      }
    }

    // Generate MST
    while (!worklist.isEmpty() && representatives.size() > 1) {
      worklist.sort((e1, e2) -> e1.weight - e2.weight);
      EdgeHex currentEdge = worklist.get(0);
      GamePieceHex from = currentEdge.fromNode;
      GamePieceHex to = currentEdge.toNode;
      if (!find(representatives, from).equals(find(representatives, to))) {
        edgesInTree.add(currentEdge);
        union(representatives, from, to);
      }
      worklist.remove(0);
    }

    this.mst = edgesInTree;
  }

  // Union find find method
  GamePieceHex find(HashMap<GamePieceHex, GamePieceHex> representatives, GamePieceHex gp) {
    if (!representatives.get(gp).equals(gp)) {
      representatives.put(gp, find(representatives, representatives.get(gp)));
    }
    return representatives.get(gp);
  }

  // Union find union method
  void union(HashMap<GamePieceHex, GamePieceHex> representatives, GamePieceHex gp1,
      GamePieceHex gp2) {
    representatives.put(find(representatives, gp2), find(representatives, gp1));
  }
}

// Represents a single game piece on the board
class GamePieceHex {
  // in logical coordinates, with the origin
  // at the top-left corner of the screen
  int row;
  int col;
  // whether this GamePiece is connected to the
  // adjacent left, right, top-left, top-right, bottom-left, or bottom-right
  // pieces
  boolean left;
  boolean right;
  boolean topLeft;
  boolean topRight;
  boolean bottomLeft;
  boolean bottomRight;
  // whether the power station is on this piece
  boolean powerStation;
  boolean powered;

  // Constructor for GamePiece
  GamePieceHex(int row, int col) {
    this.row = row;
    this.col = col;
    this.left = false;
    this.right = false;
    this.topLeft = false;
    this.topRight = false;
    this.bottomLeft = false;
    this.bottomRight = false;
    this.powerStation = false;
    this.powered = false;
  }

  // Generate an image of this, the given GamePiece.
  // - size: the size of the tile, in pixels
  // - wireWidth: the width of wires, in pixels
  // - poweredWireColor: the color of wire when powered
  WorldImage draw(int size, int wireWidth, Color poweredWireColor) {
    Color wireColor = Color.GRAY;
    if (this.powered) {
      wireColor = poweredWireColor;
    }

    WorldImage hexagon = new EquilateralTriangleImage(size, OutlineMode.SOLID, Color.DARK_GRAY);
    WorldImage vWire = new RectangleImage(wireWidth, (int) (size * Math.sqrt(3) / 2),
        OutlineMode.SOLID, wireColor);
    WorldImage hWire = new RectangleImage((int) (size * Math.sqrt(3)), wireWidth, OutlineMode.SOLID,
        wireColor);

    if (this.topLeft) {
      hexagon = new OverlayOffsetAlign(AlignModeX.LEFT, AlignModeY.TOP, vWire, 0, 0, hexagon);
    }
    if (this.topRight) {
      hexagon = new OverlayOffsetAlign(AlignModeX.RIGHT, AlignModeY.TOP, vWire, 0, 0, hexagon);
    }
    if (this.bottomLeft) {
      hexagon = new OverlayOffsetAlign(AlignModeX.LEFT, AlignModeY.BOTTOM, vWire, 0, 0, hexagon);
    }
    if (this.bottomRight) {
      hexagon = new OverlayOffsetAlign(AlignModeX.RIGHT, AlignModeY.BOTTOM, vWire, 0, 0, hexagon);
    }
    if (this.left) {
      hexagon = new OverlayOffsetAlign(AlignModeX.LEFT, AlignModeY.MIDDLE, hWire, 0, 0, hexagon);
    }
    if (this.right) {
      hexagon = new OverlayOffsetAlign(AlignModeX.RIGHT, AlignModeY.MIDDLE, hWire, 0, 0, hexagon);
    }
    if (this.powerStation) {
      hexagon = new OverlayImage(
          new OverlayImage(new StarImage(size / 3, 7, OutlineMode.OUTLINE, new Color(255, 128, 0)),
              new StarImage(size / 3, 7, OutlineMode.SOLID, new Color(0, 255, 255))),
          hexagon);
    }
    return hexagon;
  }

  // Update the power station status of this GamePiece
  void updatePowerStation() {
    this.powerStation = !this.powerStation;
  }

  // Rotate the GamePiece clockwise a certain number of times
  void rotate(int rotations) {
    for (int i = 0; i < rotations; i++) {
      boolean temp = this.topLeft;
      this.topLeft = this.bottomLeft;
      this.bottomLeft = this.bottomRight;
      this.bottomRight = this.right;
      this.right = this.topRight;
      this.topRight = this.topLeft;
      this.topLeft = temp;
    }
  }

  // Check if this GamePiece is connected to another piece
  boolean isConnectedTo(GamePieceHex other) {
    int colDiff = Math.abs(this.col - other.col);
    int rowDiff = Math.abs(this.row - other.row);

    if (colDiff <= 1 && rowDiff <= 1) {
      if (this.row == other.row) {
        if (this.col == other.col - 1) {
          return other.left && this.right;
        }
        else if (this.col == other.col + 1) {
          return other.right && this.left;
        }
      }
      else if (this.row == other.row - 1 && this.col == other.col) {
        return other.bottomLeft && this.topRight;
      }
      else if (this.row == other.row + 1 && this.col == other.col) {
        return other.topLeft && this.bottomRight;
      }
    }
    return false;
  }

  // Get the hexagonal neighbors of this GamePieceHex
  ArrayList<GamePieceHex> getHexNeighbors(ArrayList<ArrayList<GamePieceHex>> board) {
    ArrayList<GamePieceHex> neighbors = new ArrayList<>();

    int rowOffset = this.col % 2 == 0 ? 0 : 1; // Offset for odd rows

    if (this.row > 0) {
      // Top neighbors
      if (this.col - rowOffset >= 0) {
        neighbors.add(board.get(this.col - rowOffset).get(this.row - 1));
      }
      if (this.col + 1 - rowOffset < board.size()) {
        neighbors.add(board.get(this.col + 1 - rowOffset).get(this.row - 1));
      }
    }
    if (this.col > 0) {
      // Left neighbor
      neighbors.add(board.get(this.col - 1).get(this.row));
    }
    if (this.col < board.size() - 1) {
      // Right neighbor
      neighbors.add(board.get(this.col + 1).get(this.row));
    }
    if (this.row < board.get(this.col).size() - 1) {
      // Bottom neighbors
      if (this.col - rowOffset >= 0) {
        neighbors.add(board.get(this.col - rowOffset).get(this.row + 1));
      }
      if (this.col + 1 - rowOffset < board.size()) {
        neighbors.add(board.get(this.col + 1 - rowOffset).get(this.row + 1));
      }
    }

    return neighbors;
  }

  // Add a neighbor to the list if it's within the bounds of the board
  void addNeighbor(ArrayList<ArrayList<GamePieceHex>> board, ArrayList<GamePieceHex> neighbors,
      int row, int col) {
    if (row >= 0 && row < board.size() && col >= 0 && col < board.get(row).size()) {
      neighbors.add(board.get(row).get(col));
    }
  }
}

//Represents an edge between two GamePieces
class EdgeHex {
  GamePieceHex fromNode;
  GamePieceHex toNode;
  int weight;

  // Constructor for Edge
  EdgeHex(GamePieceHex fn, GamePieceHex tn, int weight) {
    this.fromNode = fn;
    this.toNode = tn;
    this.weight = weight;
  }

  // Method to check if two edges are equal
  boolean isEqual(EdgeHex other) {
    return (this.fromNode == other.fromNode && this.toNode == other.toNode)
        || (this.fromNode == other.toNode && this.toNode == other.fromNode);
  }
}

//Interface containing constants used throughout the game
interface IUtilsHex {
  int SCREEN_WIDTH = 480;
  int SCREEN_HEIGHT = 550;
  int TILE_SIZE = 60;
  int WIRE_WIDTH = 10;
  int GAME_WIDTH = 8;
  int GAME_HEIGHT = 8;
}

class ExamplesHex {
  LightEmAllHex game1 = new LightEmAllHex(new Random(1));

  // Test the game using BigBang
  void testBigBang(Tester t) {
    this.game1.bigBang(IUtilsHex.SCREEN_WIDTH, IUtilsHex.SCREEN_HEIGHT, 1);
  }

}